#!/usr/bin/python3

# HINT: Subscriber, subscriber, subscriber. I don't like it, I avoid.... but subscriber likes me, I can't avoid it.

import rclpy
from rclpy.node import Node

from std_msgs.msg import String


class MinimalSubscriber(Node):

      def __init__(self):
         super().__init__('minimal_subscriber')
         self.subscription = self.create_subscription(
            String,
            '/start_here',
            self.listener_callback1,
            10)
            
         # self.subscription = self.create_subscription(
         #    String,
         #    '/You_are_welcome',
         #    self.listener_callback2,
         #    10)   
        
         # self.subscription = self.create_subscription(
         #    String,
         #    '/Pasta_way',
         #    self.listener_callback3,
         #    10)
                
         # self.subscription = self.create_subscription(
         #    String,
         #    '/Bison',
         #    self.listener_callback4,
         #    10)
            
         # self.subscription = self.create_subscription(
         #    String,
         #    '/Oops',
         #    self.listener_callback5,
         #    10)
            
         # self.subscription = self.create_subscription(
         #    String,
         #    '/Rebooted',
         #    self.listener_callback6,
         #    10)
               
         self.subscription  # prevent unused variable warning

      def listener_callback1(self, msg):
       self.get_logger().info('I heard: "%s"' % msg.data)
       
      # def listener_callback2(self, msg):
      #  self.get_logger().info('I heard: "%s"' % msg.data)
       
      # def listener_callback3(self, msg):
      #  self.get_logger().info('I heard: "%s"' % msg.data)     
    
      # def listener_callback4(self, msg):
      #  self.get_logger().info('I heard: "%s"' % msg.data)
       
      # def listener_callback5(self, msg):
      #  self.get_logger().info('I heard: "%s"' % msg.data)   
		
      # def listener_callback6(self, msg):
      #  self.get_logger().info('I heard: "%s"' % msg.data) 		
    		
def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = MinimalSubscriber()

    rclpy.spin(minimal_subscriber)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()


