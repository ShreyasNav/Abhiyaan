
#include <iostream>
#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "behaviortree_cpp/action_node.h"
#include "behaviortree_cpp/bt_factory.h"

using namespace std::chrono_literals;

 class ApproachObject : public BT::SyncActionNode, public rclcpp::Node
 {
 public:

   MinimalPublisher()
   : Node("minimal_publisher")
   {
    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/player_1/cmd_vel", 10);
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "/player1_/pose", 10, std::bind(&MinimalPublisher::topic_callback, this, _1));  
   
     rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
     
    void topic_callback(const geometry_msgs::msg::Pose & msg) const
    {
      self.player_1_pose = msg.linear.x// RCLCPP_INFO(this->get_logger(), "I heard: '%s'", msg.data.c_str());
    }
  rclcpp::Subscription<geometry_msgs::msg::Pose>::SharedPtr subscription_;
   }
   explicit ApproachObject(const std::string &name) : BT::SyncActionNode(name, {})
   {
      auto message = geometry_msgs::msg::Twist();
     
   	while(self.player_1_pose > 6.5)
   		message.linear.x = 1.0;
   		message.linear.y = 0.0;
   		publisher_->publish(message);
  		
     	if (self.player_1_pose == 6.5):
  		message.linear.x = 0.0
   		message.linear.y = 0.0
  		publisher_->publish(message);
  			
   }

   BT::NodeStatus tick() override
   {
     std::cout << "Approach Object: " << this->name() << std::endl;
     //std::this_thread::sleep_for(5s);
    if (self.player_1_pose.x == 6.5):
     	return BT::NodeStatus::SUCCESS;
     else:
     	return BT::NodeStatus::FAILURE;
  }
  
  
 };

 class PassTheBall : public BT::SyncActionNode
 {
 public:
  MinimalPublisher()
   : Node("minimal_publisher")
   {
    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/ball/cmd_vel", 10);
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "/ball/Pose", 10, std::bind(&MinimalPublisher::topic_callback1, this, _1));  
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "/Player_2/Pose", 10, std::bind(&MinimalPublisher::topic_callback2, this, _1));    
   

     rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
     
    void topic_callback2(const geometry_msgs::msg::Pose & msg) const
    {
      self.player_2_posex = msg.linear.x
      self.player_2_posey = msg.linear.y
    }
    void topic_callback1(const geometry_msgs::msg::Pose & msg) const
    {
      self.ball_posex = msg.linear.x
      self.ball_posey = msg.linear.y
    }
  rclcpp::Subscription<geometry_msgs::msg::Pose>::SharedPtr subscription_;
   }
   explicit PassTheBall(const std::string &name) : BT::SyncActionNode(name, {})
   {   
      auto message1 = geometry_msgs::msg::Twist(); 
  	
   	while(self.ball_posex != self.player_2_posex or self.ball_posey != self.player_2_posey)
   		message1.linear.x = 0.5
  		message1.linear.y = 0.9
      publisher_->publish(message1);
	
	  if (self.ball_posex == self.player_2_posex and self.ball_posey == self.player_2_posey)
   		message1.linear.x = 0.0   
      message1.linear.y = 0.0
      publisher_->publish(message1);
   }

   BT::NodeStatus tick() override
   {
     std::cout << "PassTheBall: " << this->name() << std::endl;

     //std::this_thread::sleep_for(5s);
      if (ball_posex == player_2_posex and ball_posey == player_2_posey):
     	return BT::NodeStatus::SUCCESS;
     else:
    	return BT::NodeStatus::FAILURE;
   }
    };

 class Goal : public BT::SyncActionNode
 {
 public:
  MinimalPublisher()
   : Node("minimal_publisher")
   {
    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/player_1/cmd_vel", 10);
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "/ball/Pose", 10, std::bind(&MinimalPublisher::topic_callback1, this, _1));

    void topic_callback1(const geometry_msgs::msg::Pose & msg) const
    {
      self.ball_posex = msg.linear.x
      self.ball_posey = msg.linear.y
    }  
     
   }
   explicit Goal(const std::string &name) : BT::SyncActionNode(name, {})
   {
    auto message3 = geometry_msgs::msg::Twist();

   	message3.linear.x = 1.0;
   	message3.linear.y = 0.0;
    publisher_->publish(message3);
   }

   BT::NodeStatus tick() override
  {
     std::cout << "Goal: " << this->name() << std::endl;

     //std::this_thread::sleep_for(5s);
     if (self.ball_posey < 1):
    	return BT::NodeStatus::SUCCESS;
    else:
    	return BT::NodeStatus::FAILURE;
   }
  };

int main()
{
  BT::BehaviorTreeFactory factory;
  //Registering the nodes

  factory.registerNodeType<ApproachObject>("ApproachObject");

  factory.registerNodeType<PassTheBall>("PassTheBall");

  factory.registerNodeType<Goal>("Goal");

  //Create Tree
  auto tree = factory.createTreeFromFile("./../bt_tree.xml");

  //execute the tree
  tree.tickRoot();

  return 0;
}




