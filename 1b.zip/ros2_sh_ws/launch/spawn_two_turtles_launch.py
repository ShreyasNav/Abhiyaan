from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch.substitutions import FindExecutable
from launch_ros.actions import Node


def generate_launch_description():
    ld = LaunchDescription(
        [
            Node(
                package="turtlesim",
                executable="turtlesim_node",
                name="turtlesim",
            ),
            Node(
                package="q1b",
                executable="turtle_pingpong",
                name="turtle_control"
            )
        ]
    )
    ld.add_action(
        ExecuteProcess(
            cmd=[
                [
                    FindExecutable(name="ros2"),
                    " service call ",
                    "/spawn ",
                    "turtlesim/srv/Spawn ",
                    "\"{x: 5.544445 , y: 2.0, theta: 0.0, name: 'turtle2'}\"",
                ]
            ],
            shell=True,
        )
    )
    return ld
