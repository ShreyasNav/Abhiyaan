import pygame
from constant import *


class KeyboardTracker:
    def __init__(self):
        """
        Initialize the class with key_counts set to initial values and x, y set to None.
        """
        self.key_counts = {
            "up": 0,
            "down": 0,
            "left": 0,
            "right": 0
        }
        self.x = None
        self.y = None

    def track_keys(self, event):
        """
        Track the keys pressed in the event and update the counts in the key_counts dictionary accordingly.
        Parameters:
            - event: The event containing information about the key pressed.
        Return: None
        """
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.key_counts["up"] += 1
            elif event.key == pygame.K_DOWN:
                self.key_counts["down"] += 1
            elif event.key == pygame.K_LEFT:
                self.key_counts["left"] += 1
            elif event.key == pygame.K_RIGHT:
                self.key_counts["right"] += 1

    def pub_odom(self):
        """
        Method to calculate the x and y coordinates based on the key counts and return the result.
        """
        self.x = (-self.key_counts["left"] + self.key_counts["right"]) * SPEED
        self.y = (-self.key_counts["up"] + self.key_counts["down"]) * SPEED
        return self.x, self.y
