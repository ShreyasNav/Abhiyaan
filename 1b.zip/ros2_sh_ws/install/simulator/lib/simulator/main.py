#!/usr/bin/env python


import pygame
from building import Wall, generate_map
from bot import Bot
from constant import *
import time
import rclpy
from rclpy.node import Node
from simulator.msg import Lidar, Gps, Odom

from geometry_msgs.msg import Point, Twist
pygame.init()


x = WIDTH // 2
y = HEIGHT // 2

walls = []

lidar_data = []


class Simulation(Node):
    def __init__(self):
        """
        Initialize the node and all the publishers and subscribers
        """
        global walls
        super().__init__("simulator")

        # Create all the publishers
        self.lidar_pub = self.create_publisher(Lidar, '/lidar', 10)
        self.gps_pub = self.create_publisher(Gps, '/gps', 10)
        self.odom_pub = self.create_publisher(Odom, '/odom', 10)

        # Create subscriber for cmd_vel
        self.cmd_vel = Twist()
        self.cmd_vel_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_vel_callback,
            1)
        self.refresh_rate = 100
        # Initialize bot position to center of the screen
        self.bot_x, self.bot_y = WIDTH // 2, HEIGHT // 2

        # Initialize offsets
        self.xoff, self.yoff = 0, 10000

        # Generate the map and extend the walls
        walls = generate_map()
        walls.extend([
            Wall(pygame.Vector2(-1, -1), pygame.Vector2(WIDTH, -1)),
            Wall(pygame.Vector2(WIDTH, -1), pygame.Vector2(WIDTH, HEIGHT)),
            Wall(pygame.Vector2(WIDTH, HEIGHT), pygame.Vector2(-1, HEIGHT)),
            Wall(pygame.Vector2(-1, HEIGHT), pygame.Vector2(-1, -1))
        ])
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Localization")
        self.clock = pygame.time.Clock()
        self.timer = self.create_timer(1 / self.refresh_rate, self.draw)
        
        
    def cmd_vel_callback(self, msg):
        """
        Callback function to handle changes in cmd_vel.

        This function is called everytime a new Twist message is received on
        the /cmd_vel topic.

        Parameters:
            msg (Twist): The Twist message received on /cmd_vel.
        """
        self.cmd_vel = msg
        self.bot_x += self.cmd_vel.linear.x
        self.bot_y += self.cmd_vel.linear.y
        print("cmd vel subscribed")
        
        
    def draw(self):
        """Draw the updated map with the new bot position and publish Lidar and GPS messages."""
        
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.destroy_timer(self.timer)
        lidar_data = []

        self.particle = Bot(self.bot_x, self.bot_y)
        self.screen.fill((0, 0, 0))
        for wall in walls:    
            wall.show(self.screen)

        self.particle.update(self.bot_x, self.bot_y)

        # Get the Lidar data and draw the Lidar points on the screen
        lidar_data = self.particle.look(walls, self.screen)
        self.particle.show(self.screen)
        

        # Publish Lidar message
        lidar_msg = Lidar()
        lidar_msg.points = [Point(x=x, y=y, z=0.0) for x, y in lidar_data]
        self.lidar_pub.publish(lidar_msg)

        # Publish GPS message
        gps_msg = Gps()
        gps_data = self.particle.gps
        gps_msg.coordinates = Point(x=gps_data[0], y=gps_data[1], z=0.0)
        self.gps_pub.publish(gps_msg)

        # Update the x and y offsets to create a moving effect
        self.xoff += 0.01
        self.yoff += 0.01
        time.sleep(0.1)
        pygame.display.update()
        self.clock.tick(30)



def main(args=None):
    """
    Main function for the ROS2 simulation node.

    This function initializes the ROS2 node and spin()s the callback function.
    It also destroys the node and shuts down the ROS2 system when it's done.

    Args:
        args: The arguments to be passed to rclpy.init()
    """
    rclpy.init(args=args)
    simulator = Simulation()
    # draw_thread_instance = threading.Thread(target=draw_thread, args=(simulator,))
    # draw_thread_instance.start()

    rclpy.spin(simulator)
    simulator.destroy_node()
    rclpy.shutdown()

    


if __name__ == "__main__":
    main()