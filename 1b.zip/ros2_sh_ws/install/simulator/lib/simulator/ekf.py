#!/usr/bin/env python

import pygame
import rclpy
from constant import *
from rclpy.node import Node
from simulator.msg import Lidar, Gps
import time
pygame.init()

class Ekf(Node):
    def __init__(self):
        """
        Initializes the EKF class.
        """
        super().__init__("ekf")
        self.lidar = Lidar()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Mapping")
        self.clock = pygame.time.Clock()
        self.refresh_rate = 100
        self.ekf_sub = self.create_subscription(Lidar, '/lidar', self.lidar_callback, 10)
        self.ekf_sub = self.create_subscription(Gps, '/gps', self.gps_callback, 10)
        self.timer = self.create_timer(1 / self.refresh_rate, self.process)
    def lidar_callback(self, msg):
        """
        Sets the value of the lidar attribute to the given message.

        :param msg: The message to set the lidar attribute to.
        :type msg: Any
        :return: None
        """
        self.lidar = msg
        

    def gps_callback(self, msg):
        """
        Callback function for GPS data. Assigns the received message to the self.gps attribute.
        """
        self.gps = msg
    
    def process(self):
        """
        Process the events and draw the lidar data on the screen.

        This function processes the events received by the pygame window and handles the QUIT event to destroy the timer. It also fills the screen with black color and then iterates over the lidar data to draw the lidar points on the screen. The lidar points are offset by the GPS coordinates to ensure they are drawn in the correct position. After drawing the lidar points, the function updates the screen, sleeps for 0.1 seconds, and updates the clock to maintain a frame rate of 30 frames per second.

        Parameters:
        - None

        Returns:
        - None
        """
        
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.destroy_timer(self.timer)
        self.screen.fill((0, 0, 0))
            
        lidar_data = self.lidar.points
        for data in lidar_data:
            x = data.x + self.gps.coordinates.x
            y = data.y + self.gps.coordinates.y
            pygame.draw.rect(self.screen, (255, 255, 255), pygame.Rect(x, y, 1, 1))
        time.sleep(0.1)
        pygame.display.update()
        self.clock.tick(30)


def main(args=None):
    """
    Initializes the ROS 2 client library with the given arguments and creates an instance of the `Ekf` class.
    Spins the ROS 2 event loop until the node is shut down.
    
    :param args: Optional arguments to be passed to the ROS 2 client library initialization.
    :type args: Any
    
    :return: None
    :rtype: None
    """
    rclpy.init(args=args)
    ekf = Ekf()

    rclpy.spin(ekf)
    ekf.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()