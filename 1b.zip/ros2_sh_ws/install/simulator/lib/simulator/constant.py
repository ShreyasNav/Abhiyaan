from typing import Tuple

WIDTH: int = 800
HEIGHT: int = 600
FPS: int = 60
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)

NUM_OBSTACLE: int = 10

# Robot Parameters
BOT_RADIUS = 10
SPEED = 2

