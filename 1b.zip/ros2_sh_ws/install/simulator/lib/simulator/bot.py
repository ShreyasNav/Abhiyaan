import pygame
import numpy as np
import math
from ray import Ray


class Bot:
    def __init__(self, x, y):
        """
        Initializes the object with the given x and y coordinates.

        Parameters:
            x (int): The x coordinate.
            y (int): The y coordinate.

        Returns:
            None
        """
        self.pos = pygame.Vector2(x, y)
        self.rays = [Ray(self.pos, math.radians(a)) for a in range(0, 360, 3)]

    def update(self, x, y):
        """
        Update the position of the object.

        Parameters:
            x (int): The x-coordinate of the new position.
            y (int): The y-coordinate of the new position.
        """
        self.pos = pygame.Vector2(x, y)

    def look(self, walls, screen):
        """
        Calculates the Lidar data for the given walls.

        Parameters:
            walls (list): A list of walls in the environment.

        Returns:
            list: A list of closest points of intersection for each ray in the Lidar.
        """
        
        
        lidar_data = []
        for ray in self.rays:
            closest = None
            record = float('inf')
            for wall in walls:
                pt = ray.cast(wall)
                if pt:
                    d = pygame.Vector2.distance_to(self.pos, pt)
                    if d < record:
                        record = d
                        closest = pt
            if closest:
                pygame.draw.line(screen, (255, 100, 100), self.pos, closest)
                lidar_data.append(closest-self.pos)
                
                pygame.draw.circle(screen, (255, 0, 255), closest, 4)
        return lidar_data

    def show(self, screen):
        """
        Draws a rectangle on the given screen at the position specified by the object's `pos` attribute.

        Parameters:
            screen (pygame.Surface): The surface on which to draw the rectangle.

        Returns:
            None
        """
        pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(self.pos.x, self.pos.y, 20, 10))

    @property
    def gps(self):
        """
        Returns the current position of the bot with some noise added.

        The noise is generated from a normal distribution with mean 0 and standard
        deviation 1. This is added to the position of the bot to simulate real-world
        GPS inaccuracies.

        Returns:
            pygame.Vector2: The position of the bot with some noise added.
        """
        noise = [np.random.normal(0, 1, 1), np.random.normal(0, 1, 1)]
        return self.pos + pygame.Vector2(noise)
