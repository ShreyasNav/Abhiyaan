import pygame
from maze import Maze
from constant import *

class Wall():
    def __init__(self, start, end):
        """Constructor for the Wall class.

        Args:
            start: The starting point of the Wall in (x,y) format
            end: The ending point of the Wall in (x,y) format
        """
        self.start = start #: The starting point of the Wall
        self.end = end #: The ending point of the Wall
        
    def show(self, screen):
        """
        Draw the Wall on the given screen.

        Args:
            screen (pygame.Surface): The surface on which to draw the Wall.
        """
        pygame.draw.line(screen, (255, 255, 255), self.start, self.end)

        

def generate_map():
    """
    Generate a list of Walls based on the current maze dimensions and difficulty setting.

    The maze dimensions and difficulty are determined by the `dim` and `diff` module-level variables.

    Returns:
        A list of Walls in the generated maze.
    """
    size = (WIDTH, HEIGHT)
    diff = 1
    dim = '5x5'
    Walls = []
    # Number of rows and columns in the maze
    dim = map(int, dim.split('x'))

    # List of Walls in the generated maze
    Walls = []

    maze_obj = Maze(*dim)  # create a maze object with the given dimensions
    if diff == 0:  # generate the maze with a recursive backtracking algorithm
        maze_obj.generate(maze_obj.maze[(0, 0)])
    else:  # generate the maze with a recursive division method
        maze_obj.generate()

    cell_width = size[0] / maze_obj.cols  # width of each maze cell
    cell_height = size[1] / maze_obj.rows  # height of each maze cell

    for y in range(maze_obj.rows):  # iterate over each row of the maze
        for x in range(maze_obj.cols):  # iterate over each column of the maze
            if not maze_obj.maze[(x, y)]['south']:  # if there is no south wall
                Walls.append(Wall(  # add a wall to the east side of the cell
                    pygame.Vector2(x * cell_width + cell_width, y * cell_height),
                    pygame.Vector2(x * cell_width + cell_width, y * cell_height + cell_height)))
            if not maze_obj.maze[(x, y)]['east']:  # if there is no east wall
                Walls.append(Wall(  # add a wall to the south side of the cell
                    pygame.Vector2(x * cell_width, y * cell_height + cell_height),
                    pygame.Vector2(x * cell_width + cell_width, y * cell_height + cell_height)))

    return Walls
