import pygame
import math


class Ray:
    def __init__(self, pos, angle):
        """
        Initializes a new instance of the class.

        Args:
            pos (tuple): The position of the object.
            angle (float): The angle of the object.

        Returns:
            None
        """
        self.pos = pos
        self.dir = pygame.Vector2(math.cos(angle), math.sin(angle))

    def lookat(self, x, y):
        """
        Calculate the direction vector from the current position to the given (x, y) coordinates and normalize it in place.

        Parameters:
            x (int): The x-coordinate to look at.
            y (int): The y-coordinate to look at.
        """
        self.dir.x = x - self.pos.x
        self.dir.y = y - self.pos.y
        self.dir.normalize_ip()

    def show(self, screen):
        """
        Draws a line on the screen from the current position to the position offset by the direction vector multiplied by 10. 
        Args:
            screen: The Pygame screen object to draw on.
        
        Returns:
            The updated position after moving in the direction of self.dir by 10 units.
        """
        pygame.draw.line(screen, (255, 255, 255), self.pos, self.pos + self.dir * 10)
        return self.pos + self.dir * 10

    def cast(self, wall):
        """
        A function to calculate the intersection point of a line segment with the current object's direction.
        Parameters:
        - wall: The wall to calculate intersection with.
        Returns:
        - The intersection point if it exists, otherwise None.
        """
        x1, y1 = wall.start.x, wall.start.y
        x2, y2 = wall.end.x, wall.end.y
        x3, y3 = self.pos.x, self.pos.y
        x4, y4 = self.pos.x + self.dir.x, self.pos.y + self.dir.y

        den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if den == 0:
            return None

        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / den

        if 0 < t < 1 and u > 0:
            pt = pygame.Vector2(x1 + t * (x2 - x1), y1 + t * (y2 - y1))
            return pt
        else:
            return None
