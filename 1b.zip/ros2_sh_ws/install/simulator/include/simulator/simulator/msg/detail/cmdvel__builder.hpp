// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from simulator:msg/Cmdvel.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__DETAIL__CMDVEL__BUILDER_HPP_
#define SIMULATOR__MSG__DETAIL__CMDVEL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "simulator/msg/detail/cmdvel__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace simulator
{

namespace msg
{

namespace builder
{

class Init_Cmdvel_linear
{
public:
  Init_Cmdvel_linear()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::simulator::msg::Cmdvel linear(::simulator::msg::Cmdvel::_linear_type arg)
  {
    msg_.linear = std::move(arg);
    return std::move(msg_);
  }

private:
  ::simulator::msg::Cmdvel msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::simulator::msg::Cmdvel>()
{
  return simulator::msg::builder::Init_Cmdvel_linear();
}

}  // namespace simulator

#endif  // SIMULATOR__MSG__DETAIL__CMDVEL__BUILDER_HPP_
