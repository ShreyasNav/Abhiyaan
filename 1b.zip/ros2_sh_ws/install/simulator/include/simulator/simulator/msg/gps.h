// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulator:msg/Gps.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__GPS_H_
#define SIMULATOR__MSG__GPS_H_

#include "simulator/msg/detail/gps__struct.h"
#include "simulator/msg/detail/gps__functions.h"
#include "simulator/msg/detail/gps__type_support.h"

#endif  // SIMULATOR__MSG__GPS_H_
