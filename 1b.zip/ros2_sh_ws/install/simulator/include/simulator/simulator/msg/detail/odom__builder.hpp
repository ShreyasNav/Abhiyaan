// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from simulator:msg/Odom.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__DETAIL__ODOM__BUILDER_HPP_
#define SIMULATOR__MSG__DETAIL__ODOM__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "simulator/msg/detail/odom__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace simulator
{

namespace msg
{

namespace builder
{

class Init_Odom_coordinates
{
public:
  explicit Init_Odom_coordinates(::simulator::msg::Odom & msg)
  : msg_(msg)
  {}
  ::simulator::msg::Odom coordinates(::simulator::msg::Odom::_coordinates_type arg)
  {
    msg_.coordinates = std::move(arg);
    return std::move(msg_);
  }

private:
  ::simulator::msg::Odom msg_;
};

class Init_Odom_header
{
public:
  Init_Odom_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Odom_coordinates header(::simulator::msg::Odom::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Odom_coordinates(msg_);
  }

private:
  ::simulator::msg::Odom msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::simulator::msg::Odom>()
{
  return simulator::msg::builder::Init_Odom_header();
}

}  // namespace simulator

#endif  // SIMULATOR__MSG__DETAIL__ODOM__BUILDER_HPP_
