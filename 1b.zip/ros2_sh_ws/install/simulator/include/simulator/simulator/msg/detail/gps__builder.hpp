// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from simulator:msg/Gps.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__DETAIL__GPS__BUILDER_HPP_
#define SIMULATOR__MSG__DETAIL__GPS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "simulator/msg/detail/gps__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace simulator
{

namespace msg
{

namespace builder
{

class Init_Gps_coordinates
{
public:
  explicit Init_Gps_coordinates(::simulator::msg::Gps & msg)
  : msg_(msg)
  {}
  ::simulator::msg::Gps coordinates(::simulator::msg::Gps::_coordinates_type arg)
  {
    msg_.coordinates = std::move(arg);
    return std::move(msg_);
  }

private:
  ::simulator::msg::Gps msg_;
};

class Init_Gps_header
{
public:
  Init_Gps_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Gps_coordinates header(::simulator::msg::Gps::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Gps_coordinates(msg_);
  }

private:
  ::simulator::msg::Gps msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::simulator::msg::Gps>()
{
  return simulator::msg::builder::Init_Gps_header();
}

}  // namespace simulator

#endif  // SIMULATOR__MSG__DETAIL__GPS__BUILDER_HPP_
