// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulator:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__LIDAR_H_
#define SIMULATOR__MSG__LIDAR_H_

#include "simulator/msg/detail/lidar__struct.h"
#include "simulator/msg/detail/lidar__functions.h"
#include "simulator/msg/detail/lidar__type_support.h"

#endif  // SIMULATOR__MSG__LIDAR_H_
