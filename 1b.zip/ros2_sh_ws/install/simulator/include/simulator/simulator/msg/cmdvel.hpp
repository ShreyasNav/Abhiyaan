// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__CMDVEL_HPP_
#define SIMULATOR__MSG__CMDVEL_HPP_

#include "simulator/msg/detail/cmdvel__struct.hpp"
#include "simulator/msg/detail/cmdvel__builder.hpp"
#include "simulator/msg/detail/cmdvel__traits.hpp"

#endif  // SIMULATOR__MSG__CMDVEL_HPP_
