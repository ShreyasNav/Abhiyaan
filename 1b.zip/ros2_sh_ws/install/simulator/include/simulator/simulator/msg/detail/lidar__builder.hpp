// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from simulator:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__DETAIL__LIDAR__BUILDER_HPP_
#define SIMULATOR__MSG__DETAIL__LIDAR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "simulator/msg/detail/lidar__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace simulator
{

namespace msg
{

namespace builder
{

class Init_Lidar_points
{
public:
  explicit Init_Lidar_points(::simulator::msg::Lidar & msg)
  : msg_(msg)
  {}
  ::simulator::msg::Lidar points(::simulator::msg::Lidar::_points_type arg)
  {
    msg_.points = std::move(arg);
    return std::move(msg_);
  }

private:
  ::simulator::msg::Lidar msg_;
};

class Init_Lidar_header
{
public:
  Init_Lidar_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Lidar_points header(::simulator::msg::Lidar::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Lidar_points(msg_);
  }

private:
  ::simulator::msg::Lidar msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::simulator::msg::Lidar>()
{
  return simulator::msg::builder::Init_Lidar_header();
}

}  // namespace simulator

#endif  // SIMULATOR__MSG__DETAIL__LIDAR__BUILDER_HPP_
