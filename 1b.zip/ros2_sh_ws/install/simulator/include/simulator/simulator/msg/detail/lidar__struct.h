// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from simulator:msg/Lidar.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__DETAIL__LIDAR__STRUCT_H_
#define SIMULATOR__MSG__DETAIL__LIDAR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'points'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/Lidar in the package simulator.
typedef struct simulator__msg__Lidar
{
  std_msgs__msg__Header header;
  geometry_msgs__msg__Point__Sequence points;
} simulator__msg__Lidar;

// Struct for a sequence of simulator__msg__Lidar.
typedef struct simulator__msg__Lidar__Sequence
{
  simulator__msg__Lidar * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} simulator__msg__Lidar__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SIMULATOR__MSG__DETAIL__LIDAR__STRUCT_H_
