// generated from rosidl_generator_c/resource/idl.h.em
// with input from simulator:msg/Cmdvel.idl
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__CMDVEL_H_
#define SIMULATOR__MSG__CMDVEL_H_

#include "simulator/msg/detail/cmdvel__struct.h"
#include "simulator/msg/detail/cmdvel__functions.h"
#include "simulator/msg/detail/cmdvel__type_support.h"

#endif  // SIMULATOR__MSG__CMDVEL_H_
