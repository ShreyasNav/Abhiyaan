// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SIMULATOR__MSG__LIDAR_HPP_
#define SIMULATOR__MSG__LIDAR_HPP_

#include "simulator/msg/detail/lidar__struct.hpp"
#include "simulator/msg/detail/lidar__builder.hpp"
#include "simulator/msg/detail/lidar__traits.hpp"

#endif  // SIMULATOR__MSG__LIDAR_HPP_
