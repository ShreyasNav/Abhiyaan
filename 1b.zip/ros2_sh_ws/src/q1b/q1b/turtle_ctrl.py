# Node to command or control the velocities of the two turtle
# This containts two subscribers and publishers 
# each for ball turtle (turtle1) and ping_turtle (turtle2)

# ros2 essentials
import rclpy
from rclpy.node import Node

# msgs
from geometry_msgs.msg import Twist
from std_msgs.msg import String
from turtlesim.msg import Pose as TurtlesimPose

# global variables
 #making position array
#t1_position = [0,0,0]
#t2_position = [0,0,0]


class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')

        # 2 Publishers
        self.turtle1_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self.turtle2_pub = self.create_publisher(Twist, '/turtle2/cmd_vel', 10)
        
        # Subscriber 1
        self.turtle1_sub = self.create_subscription(
            TurtlesimPose,
            '/turtle1/pose',
            self.turtle1_sub_callback,
            10)
        # self.turtle1_sub # prevent unused variable warning

        # Subscriber 2
        self.turtle2_sub = self.create_subscription(
            TurtlesimPose,
            '/turtle2/pose',
            self.turtle2_sub_callback,
            10)
        # self.turtle2_sub # prevent unused variable warning
        

        # Timer
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0


    def turtle1_sub_callback(self, msg1):
        # write here what to do with the turtle 1 position

        # storing message value in position vector/array/list
        ##t1_position = [msg1.x,msg1.y,msg1.theta]
        self.turtle1_pose = msg1
        # self.get_logger().info('I heard: "%f"' % msg.x)

    def turtle2_sub_callback(self, msg2):
        # write here what to do with the turtle 1 position

        # storing message value in position vector/array/list
        ##t2_position = [msg2.x,msg2.y,msg2.theta]
        self.turtle2_pose = msg2
        self.get_logger().info('position of ping turtle is: "%f"' % msg2.x)


    def timer_callback(self):
        
        # empty messages
        pub_msg1 = Twist()
        pub_msg2 = Twist()
        
        #initialising velocities
        x_vel = -20
        y_vel = 10

        # code to make turtle bounce of walls and of turlte 2
        if (self.turtle1_pose.x > 11):
        	pub_msg1.linear.x = -x_vel 
        	pub_msg1.linear.y = y_vel
        	x_vel = -x_vel
        	y_vel = y_vel
        	self.turtle1_pub.publish(pub_msg1)
        
        elif (self.turtle1_pose.y > 11):
        	pub_msg1.linear.x = x_vel 
        	pub_msg1.linear.y = -y_vel
        	x_vel = x_vel
        	y_vel = -y_vel
        	self.turtle1_pub.publish(pub_msg1)
        	
        elif (self.turtle1_pose.x < 0.5):
        	pub_msg1.linear.x = -x_vel 
        	pub_msg1.linear.y = y_vel
        	x_vel = -x_vel
        	y_vel = y_vel
        	self.turtle1_pub.publish(pub_msg1)
        	
        elif (self.turtle1_pose.x == self.turtle2_pose.x  and self.turtle1_pose.y == self.turtle2_pose.y) :
        	pub_msg1.linear.x = x_vel 
        	pub_msg1.linear.y = -y_vel
        	x_vel = x_vel
        	y_vel = -y_vel
        	self.turtle1_pub.publish(pub_msg1)
        else :
        	pub_msg1.linear.x = x_vel 
        	pub_msg1.linear.y = y_vel
        	self.turtle1_pub.publish(pub_msg1)
        #pub_msg1.angular.z = 0.1
        

        # turtle 2 follow x coordinates of turtle
        pub_msg2.linear.x = x_vel
        #pub_msg2.angular.z = 0.2
        self.turtle2_pub.publish(pub_msg2)

        # next step
        self.i += 1


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

