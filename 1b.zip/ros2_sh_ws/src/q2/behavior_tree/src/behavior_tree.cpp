
#include <iostream>
#include <chrono>
#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "behaviortree_cpp/action_node.h"
#include "behaviortree_cpp/bt_factory.h"

using namespace std::chrono_literals;

 class ApproachObject : public BT::SyncActionNode, public rclcpp::Node
 {
 public:

   MinimalPublisher()
   : Node("minimal_publisher"), count_(0)
   {
    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/player_1/cmd_vel", 10);
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "topic", 10, std::bind(&MinimalPublisher::topic_callback, this, _1));  

     timer_ = this->create_wall_timer(
     500ms, std::bind(&MinimalPublisher::timer_callback, this));
   }

    void timer_callback()
     {
//       auto message = geometry_msgs::msg::Twist();  
//     }
//     //rclcpp::TimerBase::SharedPtr timer_;
//     rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
//     
    
//   explicit ApproachObject(const std::string &name) : BT::SyncActionNode(name, {})
//   {
//      auto message = geometry_msgs::msg::Twist();
     
//   	while(self.player_1_pose.x > 6.5)
//   		message.linear.x = 1.0;
//   		message.linear.y = 0.0;
//   		publisher_->publish(message);
  		
//     	if (self.player_1_pose.x == 6.5):
//   		player_1_vel.x = 0.0
//   		player_1_vel.y = 0.0
//   		self.player_1_velocity_publisher.publish(twist)
  			
//   }

//   BT::NodeStatus tick() override
//   {
//     std::cout << "Approach Object: " << this->name() << std::endl;

//     //std::this_thread::sleep_for(5s);
//     if (self.player_1_pose.x == 6.5):
//     	return BT::NodeStatus::SUCCESS;
//     else:
//     	return BT::NodeStatus::FAILURE;
//   }
  
  
// };

// // class PassTheBall : public BT::SyncActionNode
// // {
// // public:
// //   explicit PassTheBall(const std::string &name) : BT::SyncActionNode(name, {})
// //   {
  	
// //   	while(ball_pose.x != player_2_pose.x or ball_pose.y != player_2_pose.y)
// //   		ball_vel.x = 0.5
// //   		ball_vel.y = 0.9
	
// // 	if (ball_pose.x == player_2_pose.x and ball_pose.y == player_2_pose.y)
// //   		ball_vel.x = 0.0
// //   		ball_vel.y = 0.0
// //   }

// //   BT::NodeStatus tick() override
// //   {
// //     std::cout << "PassTheBall: " << this->name() << std::endl;

// //     //std::this_thread::sleep_for(5s);
// //     if (ball_pose.x == player_2_pose.x and ball_pose.y == player_2_pose.y:
// //     	return BT::NodeStatus::SUCCESS;
// //     else:
// //     	return BT::NodeStatus::FAILURE;
// //   }
// // };

// // class Goal : public BT::SyncActionNode
// // {
// // public:
// //   explicit Goal(const std::string &name) : BT::SyncActionNode(name, {})
// //   {
// //   	ball_vel.x = 1.0
// //   	ball_vel.y = 0.0
// //   }

// //   BT::NodeStatus tick() override
// //   {
// //     std::cout << "Goal: " << this->name() << std::endl;

// //     //std::this_thread::sleep_for(5s);
// //     if (ball_pose.y < 1):
// //     	return BT::NodeStatus::SUCCESS;
// //     else:
// //     	return BT::NodeStatus::FAILURE;
// //   }
// // };

// int main()
// {
//   BT::BehaviorTreeFactory factory;

   //Create Tree
  auto tree = factory.createTreeFromFile("./../bt_tree.xml");

  //execute the tree
   tree.tickRoot();

    return 0 ;
 }

class ApproachObject : public BT::SyncActionNode, public rclcpp::Node
{
public:
  MinimalPublisher()
  : Node("minimal_publisher")
  {
    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/player_1/cmd_vel", 10);
    timer_ = this->create_wall_timer(
      500ms, std::bind(&MinimalPublisher::timer_callback, this));
  }

  void timer_callback()
  {
      auto message = geometry_msgs::msg::Twist();
//    message.data = "Hello, world! " + std::to_string(count_++);
//    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
      message.linear.x = 1.0;
   		message.linear.y = 0.0;
  		publisher_->publish(message);
  }
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
//  size_t count_;
  explicit ApproachObject(const std::string &name) : BT::SyncActionNode(name, {})
  {

  }

  BT::NodeStatus tick() override
  {
    std::cout << "Approach Object: " << this->name() << std::endl;

    std::this_thread::sleep_for(5s);
    return BT::NodeStatus::SUCCESS;
  }
};

// BT::NodeStatus CheckBattery()
// {
//   std::cout << "Battery OK" << std::endl;
//   return BT::NodeStatus::SUCCESS;
// }

// class GripperInterface
// {
// public:
//   GripperInterface() : _open(true) {}

//   BT::NodeStatus open()
//   {
//     _open = true;
//     std::cout << "Gripper open" << std::endl;
//     return BT::NodeStatus::SUCCESS;
//   }

//   BT::NodeStatus close()
//   {
//     _open = false;
//     std::cout << "Gripper close" << std::endl;
//     return BT::NodeStatus::SUCCESS;
//   }

// private:
//   bool _open;
// };

int main()
{
  BT::BehaviorTreeFactory factory;

  factory.registerNodeType<ApproachObject>("ApproachObject");

  // factory.registerSimpleCondition("CheckBattery", std::bind(CheckBattery));

  // GripperInterface gripper;

  // factory.registerSimpleAction(
  //     "OpenGripper",
  //     std::bind(&GripperInterface::open, &gripper));

  // factory.registerSimpleAction(
  //     "CloseGripper",
  //     std::bind(&GripperInterface::close, &gripper));

  //Create Tree
  auto tree = factory.createTreeFromFile("./../bt_tree.xml");

  //execute the tree
  tree.tickRoot();

  return 0;
}




